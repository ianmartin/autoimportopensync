/*
 * Copyright (C) 2003-2007 Funambol
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "base/fscapi.h"
#include "base/util/utils.h"
#include "base/Log.h"
#include "spds/spdsutils.h"
#include <stdio.h>

#include "spds/MailMessage.h"
#include "spds/EmailData.h"

// Read a text file and convert it from UTF-8 to WCHAR
static int readFromFile(const char* path, WCHAR **message, size_t *len)
{
    char *msg = 0;
    size_t msglen;

    // Read file
    int ret = readFile(path, &msg, &msglen);
    if(ret)
        return ret;
    msg[msglen]=0;
    // Convert content
    *message = utf82wc(msg);
    *len=wcslen(*message);
    // Free memory
    delete [] msg;

    return 0;
}

#ifdef _WIN32_WCE
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nShowCmd ) 
#else
int main(int argc, char** argv) 
#endif
{
    size_t msglen=0;
    WCHAR *name[10], *msg=0;
    int i;
    const WCHAR *attach;

#ifdef _WIN32_WCE
    name[0] = stringdup(TEXT("message.xml"));
    name[1] = stringdup(TEXT("text.xml"));
    name[2] = NULL;
    attach = TEXT("/synclog.txt");
#else
    for(i=1; i<argc; i++)
       name[i-1] = utf82wc(argv[i]);
    name[i-1] = NULL;
    attach = TEXT("c:/windows/temp/synclog.txt");
#endif  
    LOG.setLevel(LOG_LEVEL_DEBUG); // Force debug level for this test.
    
    // Test parse/format loop if names were given on cmdline
    for (i=0; name[i]; i++) {
        msg = loadAndConvert(name[i]);
        if( !msg ){
            WCHAR dbg[256];
            wsprintf(dbg, TEXT("Can't open file %s\n"), name[i]);
	        LOG.error(dbg);
            continue;
        }
        
    	EmailData em;
	
        if (em.parse(msg))
            fprintf(stderr, "Parse failed on: %S\n", name[i]);

        delete [] msg;

        WCHAR outname[10];
        wsprintf(outname, TEXT("msgout%d.xml"), i);
        if ( convertAndSave( outname, em.format() ) ) {
            fprintf(stderr, "Error in convertAndSave(em)\n");
        }
    }

    // Try to send a new mail with attachment
    EmailData newmail;
    MailMessage n;
    BodyPart body;

    body.setContent(TEXT("Ma che bella la citt�!"));
    
    n.setFrom(TEXT("gazza@funambol.com"));
    n.setTo(TEXT("magi@funambol.com"));
    n.setSubject(TEXT("Test"));
    n.setBody(body);

	BodyPart a;
	a.setFilename( TEXT("pippo.txt") );
	a.setContent( attach );
	a.setEncoding( TEXT("base64") );
    n.addAttachment(a);

    newmail.setRead(true);
    newmail.setEmailItem(n);

    if ( convertAndSave( L"attachment.xml", newmail.format() ) ) {
        fprintf(stderr, "Error in convertAndSave(newmail)\n");
    }
    //extern size_t StringBuffer_memcount;
    //fprintf(stderr, "Memcount: %ld\n", StringBuffer_memcount);
    //getchar();
	return 0;
}
